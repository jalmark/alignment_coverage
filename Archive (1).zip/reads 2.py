def main():

    # Command line parameters need text file and size of sequence

    print("Hello world from Python!")


main()